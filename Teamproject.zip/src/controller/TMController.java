package controller;



import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import beans.DataBean;

@Controller
public class TMController {
	@Autowired
	SqlSessionTemplate sqltemp;
	
	@GetMapping("login")
	public String login() {
		return "login";
	}
	@PostMapping("login_result")
	public String login_result(DataBean user_dataBean,HttpServletRequest request) {
		//-----------아이디,비번 체크--------------
		int result=0;
		DataBean chk_dataBean= (DataBean)sqltemp.selectOne("test_db.select_id",user_dataBean);//한개의 행을 가져오기,chk_dataBean <- db에서 가져온행을 담은 통
		
		if(chk_dataBean!=null) {//chk_dataBean.getId()==null	<-	x
			if(user_dataBean.getId().equals(chk_dataBean.getId())){
				result=1;
				if(user_dataBean.getPw().equals(chk_dataBean.getPw())) {
					result=2;
				}
			}
		}
		
		
		//-------------로그인------------------
		if(result == 2) {//2이면 로그인  성공
			HttpSession session = request.getSession();
			session.setAttribute("session",chk_dataBean);
			return "main";
		}else if(result == 1){//1이면 비번실패
			request.setAttribute("msg", "비밀번호가 틀렸습니다.");
			request.setAttribute("id",chk_dataBean.getId());
			return "login";
		}else {//나머지면 아이디실패
			request.setAttribute("msg", "아이디가 존재하지않습니다.");
			return "login";
		}
	}
	//---------------로그아웃--------------------
	@GetMapping("logout")
	public String logout(HttpServletRequest request) {
		HttpSession session=request.getSession();
		session.setAttribute("session", null);
		return "main";
	}
	
	@GetMapping("join")
	public String join() {
		return "join";
	}
	@GetMapping("join_id")
	public String join_id(HttpServletRequest request,DataBean dataBean) {
		DataBean chk_dataBean= sqltemp.selectOne("test_db.select_id",dataBean);//commit 주의
		if(chk_dataBean!=null) {
			if(dataBean.getId().equals(chk_dataBean.getId())) {
				request.setAttribute("msg","중복된 아이디가 있습니다.");
			}
		}else {
			request.setAttribute("msg","사용가능한 아이디입니다.");
			request.setAttribute("id",dataBean.getId());
		}
		
		return "join_id";
	}
	@PostMapping("join_result")
	public String join_result(HttpServletRequest request,DataBean dataBean) {
		String tel1=request.getParameter("tel1");
		String tel2=request.getParameter("tel2");
		String tel3=request.getParameter("tel3");
		String tel=tel1+tel2+tel3;
		dataBean.setTel(tel);
		
		dataBean.setI_member(sqltemp.selectOne("test_db.select_i_member"));//i_member 1씩 증가
		sqltemp.insert("test_db.insert_data",dataBean);
		
		request.setAttribute("msg", "회원가입이 완료되었습니다.");
		return "main";
	}
	
	@GetMapping("mypage")
	public String mypage() {
		return "mypage";
	}
	@PostMapping("mypage_result")
	public String mypage_result(HttpServletRequest request,DataBean dataBean) {
		String tel1=request.getParameter("tel1");
		String tel2=request.getParameter("tel2");
		String tel3=request.getParameter("tel3");
		String tel=tel1+tel2+tel3;
		dataBean.setTel(tel);
		
		sqltemp.update("test_db.update_member",dataBean);
		
		request.setAttribute("msg","회원정보가 수정되었습니다.");
		return "mypage";
	}
	
	@GetMapping("cart")
	public String cart(Model model) {
		List<DataBean> list	=sqltemp.selectList("test_db.select_product");
		model.addAttribute("list", list);
		
		int cnt=sqltemp.selectOne("test_db.select_i_product");
		model.addAttribute("cnt", cnt);
		return "cart";
	}
	@GetMapping("cart_delete")
	public String cart_delete(DataBean dataBean) {
		sqltemp.delete("test_db.delete_product",dataBean);
		return "cart";
	}
	
	@GetMapping("order")
	public String order() {
		return "order";
	}
	
}
