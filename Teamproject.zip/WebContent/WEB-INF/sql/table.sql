drop table member;
drop table product;
drop table product_import;

create table member(
	i_member number primary key,
	id varchar(30) not null unique,
	pw varchar(30) not null,
	name varchar(100),
	tel varchar(20),
	email varchar(100),
	addr varchar(100),
	sex varchar(10),
	r_date date default sysdate
);

insert into member(i_member,id,pw,name,tel,email,addr,sex)values(1,'user','1234','lee','0101234567','lee@gmail.com','대구 달서구','남');
insert into member(i_member,id,pw,name,tel,email,addr,sex)values(2,'asd','1234','dsa','as','a','a','a');
insert into member(i_member,id,pw,name,tel,email,addr,sex)values((select count(*)+1 from member),'a','asd','dsa','as','a','a','a');

select * from member where id='1' and email='a';

create table product(
	i_product number primary key,
	name varchar(30),
	price number(10) default 0,
	pic varchar(255),
	qty number(4) default 0,
	info varchar(255),
	category varchar(100)
);
insert into product(i_product,name,price,pic,info,category)values(1,'가죽자켓',30000,'best1.jpg','상품정보','best');
insert into product(i_product,name,price,pic,info,category)values(2,'체크무늬코트',50000,'best2.jpg','ㅁㄴㅇ','best');
insert into product(i_product,name,price,pic,info,category)values(3,'',,'best3.jpg','','best');
insert into product(i_product,name,price,pic,info,category)values(4,'',,'best4.jpg','','best');
insert into product(i_product,name,price,pic,info,category)values(5,'',,'best5.jpg','','best');
insert into product(i_product,name,price,pic,info,category)values(6,'',,'best6.jpg','','best');
insert into product(i_product,name,price,pic,info,category)values(7,'회색조끼',17000,'outer1.jpg','상품정보','outer');
insert into product(i_product,name,price,pic,info,category)values(8,'',,'','','outer');
insert into product(i_product,name,price,pic,info,category)values(9,'',,'','','outer');
insert into product(i_product,name,price,pic,info,category)values(10,'',,'','','outer');
insert into product(i_product,name,price,pic,info,category)values(11,'',,'','','outer');
insert into product(i_product,name,price,pic,info,category)values(12,'',,'','','outer');
insert into product(i_product,name,price,pic,info,category)values(13,'검정색긴팔',20000,'top1.jpg','상품정보','top');
insert into product(i_product,name,price,pic,info,category)values(14,'',,'','','top');
insert into product(i_product,name,price,pic,info,category)values(15,'',,'','','top');
insert into product(i_product,name,price,pic,info,category)values(16,'',,'','','top');
insert into product(i_product,name,price,pic,info,category)values(17,'',,'','','top');
insert into product(i_product,name,price,pic,info,category)values(18,'',,'','','top');
insert into product(i_product,name,price,pic,info,category)values(19,'카키색슬랙스바지',18000,'pants1.jpg','상품정보','pants');
insert into product(i_product,name,price,pic,info,category)values(20,'',,'','','pants');
insert into product(i_product,name,price,pic,info,category)values(21,'',,'','','pants');
insert into product(i_product,name,price,pic,info,category)values(22,'',,'','','pants');
insert into product(i_product,name,price,pic,info,category)values(23,'',,'','','pants');
insert into product(i_product,name,price,pic,info,category)values(24,'',,'','','pants');
insert into product(i_product,name,price,pic,info,category)values(25,'체크무늬티',22000,'shirt1.jpg','상품정보','shirt');
insert into product(i_product,name,price,pic,info,category)values(26,'',,'','','shirt');
insert into product(i_product,name,price,pic,info,category)values(27,'',,'','','shirt');
insert into product(i_product,name,price,pic,info,category)values(28,'',,'','','shirt');
insert into product(i_product,name,price,pic,info,category)values(29,'',,'','','shirt');
insert into product(i_product,name,price,pic,info,category)values(30,'',,'','','shirt');
insert into product(i_product,name,price,pic,info,category)values(31,'키높이슬립온',25000,'shoes1.jpg','상품정보','shoes');
insert into product(i_product,name,price,pic,info,category)values(32,'',,'','','shoes');
insert into product(i_product,name,price,pic,info,category)values(33,'',,'','','shoes');
insert into product(i_product,name,price,pic,info,category)values(34,'',,'','','shoes');
insert into product(i_product,name,price,pic,info,category)values(35,'',,'','','shoes');
insert into product(i_product,name,price,pic,info,category)values(36,'',,'','','shoes');
insert into product(i_product,name,price,pic,info,category)values(37,'양말',2000,'item1.jpg','상품정보','item');
insert into product(i_product,name,price,pic,info,category)values(38,'',,'','','item');
insert into product(i_product,name,price,pic,info,category)values(39,'',,'','','item');
insert into product(i_product,name,price,pic,info,category)values(40,'',,'','','item');
insert into product(i_product,name,price,pic,info,category)values(41,'',,'','','item');
insert into product(i_product,name,price,pic,info,category)values(42,'',,'','','item');
insert into product(i_product,name,price,pic,info,category)values(43,'검정색슬랙스',20000,'sale85.jpg','상품정보','sale85');
insert into product(i_product,name,price,pic,info,category)values(44,'',,'','','sale85');
insert into product(i_product,name,price,pic,info,category)values(45,'',,'','','sale85');
insert into product(i_product,name,price,pic,info,category)values(46,'',,'','','sale85');
insert into product(i_product,name,price,pic,info,category)values(47,'',,'','','sale85');
insert into product(i_product,name,price,pic,info,category)values(48,'',,'','','sale85');

insert into product(i_product,name,price,pic,info,category)values(1,'바지',1000,'pants.png','바지입니다.','pants');
insert into product(i_product,name,price,pic,info,category)values(2,'가방',1000,'bag.png','가방입니다.','item');
insert into product(i_product,name,price,pic,info,category)values(3,'티',1000,'t-shirt.png','티셔츠입니다.','best');
insert into product(i_product,name,price,pic,info,category)values(4,'셔츠',1000,'t-shirt.png','ㅌㅌㅌ입니다.','best');
insert into product(i_product,name,price,pic,info,category)values(5,'셔츠ssssss',1000,'t-shirt.png','ㅌㅌㅌ입니다.','best');
delete from member ;
delete from product ;
delete from product where i_product=2;

update member set pw='1122',tel='123123123',email='awenfjawnef',addr='ㅁㅁㅁㅁㅁ' where id='asd';
commit;

rollback;
/*
create table product_import(
	i_pi number primary key,
	i_product number,
	qty number(4),
	i_date date default sysdate,
	foreign key(i_product) references product(i_product)
);

insert into product values(1,'이름',10000,'이미지',0,'정보');
insert into product values(2,'이름',10000,'bag.png',0,'정보');
insert into product_import values();
select * from product_import;
*/
select * from member;
select * from product order by i_product asc;
commit;-- insert하고 난후에 commit반드시하기
